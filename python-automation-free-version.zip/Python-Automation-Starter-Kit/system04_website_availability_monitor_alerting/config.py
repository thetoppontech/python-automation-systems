# ============================================================
# Script 22 — Website Availability Monitoring and Alerting
# Configuration File (Free + Pro Compatible)
# ============================================================

# ------------------------------------------------------------
# Websites to Monitor
# ------------------------------------------------------------

WEBSITES = [
    "https://www.google.com",
    "https://invalid-example-domain-12345.com"
]

REQUEST_TIMEOUT = 5
SUCCESS_STATUS_CODES = [200]

# ------------------------------------------------------------
# Reporting
# ------------------------------------------------------------

REPORT_FILE = "reports/availability_report.txt"
PRINT_TO_TERMINAL = True

# ------------------------------------------------------------
# Email Alert Configuration
# ------------------------------------------------------------

ENABLE_EMAIL_ALERT = False

SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
SMTP_USERNAME = "your_email@gmail.com"      # Replace to enable real alerts
SMTP_PASSWORD = "your_app_password"         # Replace to enable real alerts

EMAIL_SENDER = "your_email@gmail.com"
EMAIL_RECIPIENTS = [
    "your_email@gmail.com"
]

# ------------------------------------------------------------
# Slack Alert Configuration
# ------------------------------------------------------------

ENABLE_SLACK_ALERT = False

# Replace with real webhook to enable Slack alerts
SLACK_WEBHOOK_URL = "https://hooks.slack.com/services/XXX/YYY/ZZZ"

# ------------------------------------------------------------
# Alert Behavior
# ------------------------------------------------------------

ALERT_ON_FAILURE_ONLY = False