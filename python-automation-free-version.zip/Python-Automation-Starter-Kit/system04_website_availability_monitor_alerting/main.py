import time
import requests
import os
import smtplib
from email.mime.text import MIMEText
from datetime import datetime
from config import *

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
REPORT_FILE = os.path.join(BASE_DIR, REPORT_FILE)


# ------------------------------------------------------------
# EMAIL ALERT (WITH FALLBACK)
# ------------------------------------------------------------

def send_email(subject, message):
    if not ENABLE_EMAIL_ALERT:
        print("[ALERT] Email alert would be triggered here.")
        return

    # If user didn't configure credentials
    if "your_email" in SMTP_USERNAME or "your_app_password" in SMTP_PASSWORD:
        print("[ALERT] Email alert would be triggered here. (not configured)")
        return

    try:
        msg = MIMEText(message)
        msg["Subject"] = subject
        msg["From"] = EMAIL_SENDER
        msg["To"] = ", ".join(EMAIL_RECIPIENTS)

        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(SMTP_USERNAME, SMTP_PASSWORD)
            server.sendmail(EMAIL_SENDER, EMAIL_RECIPIENTS, msg.as_string())

        print("Email alert sent.")

    except Exception as e:
        print(f"Email alert failed: {e}")


# ------------------------------------------------------------
# SLACK ALERT (WITH FALLBACK)
# ------------------------------------------------------------

def send_slack(message):
    if not ENABLE_SLACK_ALERT:
        print("[ALERT] Slack notification would be triggered here.")
        return

    # If webhook not configured
    if "XXX" in SLACK_WEBHOOK_URL:
        print("[ALERT] Slack notification would be triggered here. (not configured)")
        return

    try:
        response = requests.post(
            SLACK_WEBHOOK_URL,
            json={"text": message},
            timeout=10
        )

        if response.status_code == 200:
            print("Slack alert sent.")
        else:
            print(f"Slack alert failed: {response.status_code}")

    except Exception as e:
        print(f"Slack alert error: {e}")


# ------------------------------------------------------------
# WEBSITE CHECK
# ------------------------------------------------------------

def check_website(url, timeout):
    start_time = time.time()
    status = "DOWN"
    status_code = None
    response_time = 0
    error_message = None

    try:
        response = requests.get(url, timeout=timeout)
        response_time = time.time() - start_time
        status_code = response.status_code

        if status_code in SUCCESS_STATUS_CODES:
            status = "UP"

    except requests.exceptions.RequestException as error:
        error_message = str(error)

    return {
        "url": url,
        "status": status,
        "status_code": status_code,
        "response_time": response_time,
        "error": error_message
    }


# ------------------------------------------------------------
# REPORTING
# ------------------------------------------------------------

def write_report(results):
    os.makedirs(os.path.dirname(REPORT_FILE), exist_ok=True)

    with open(REPORT_FILE, "a", encoding="utf-8") as file:
        file.write(f"\n--- Website Check ({datetime.now()}) ---\n")

        for r in results:
            file.write(f"URL: {r['url']}\n")
            file.write(f"Status: {r['status']}\n")

            if r["status_code"]:
                file.write(f"Status Code: {r['status_code']}\n")
                file.write(f"Response Time: {r['response_time']:.2f} sec\n")

            if r["error"]:
                file.write(f"Error: {r['error']}\n")

            file.write("\n")


# ------------------------------------------------------------
# MAIN
# ------------------------------------------------------------

def main():
    results = []
    failures = []

    for site in WEBSITES:
        result = check_website(site, REQUEST_TIMEOUT)
        results.append(result)

        if PRINT_TO_TERMINAL:
            print(f"\nChecking: {result['url']}")
            print(f"Status: {result['status']}")

            if result["status_code"]:
                print(f"Status Code: {result['status_code']}")
                print(f"Response Time: {result['response_time']:.2f} seconds")

            if result["error"]:
                print(f"Error: {result['error']}")

        if result["status"] == "DOWN":
            failures.append(result)

    write_report(results)

    if failures:
        message = "[CRITICAL] Website Failure Detected\n\n"

        for f in failures:
            message += f"URL: {f['url']}\n"
            message += f"Status: DOWN\n\n"

        send_email("Website Alert", message)
        send_slack(message)

        exit(2)

    print("\nAll monitored websites are UP.")
    exit(0)


if __name__ == "__main__":
    main()