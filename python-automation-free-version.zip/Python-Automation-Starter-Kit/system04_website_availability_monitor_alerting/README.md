🚀 Website Monitoring & Alert System

---

## 📌 WHAT THIS DOES

Checks if websites are UP or DOWN and alerts you when a failure is detected.

Helps you detect issues before users are impacted.

---

## ⚡ HOW IT WORKS

• Sends request to each website
• Checks response status
• Detects failures (DOWN)
• Triggers alert system (Email / Slack)
• Saves results in a report file

---

## ⚙️ CONFIGURATION

Open `config.py` and update:

• `WEBSITES` → List of URLs to monitor
• `REQUEST_TIMEOUT` → Max wait time (seconds)
• `ENABLE_EMAIL_ALERT` → True/False
• `ENABLE_SLACK_ALERT` → True/False

Example:

WEBSITES = [
"https://www.google.com",
"https://example.com"
]

---

## ▶️ HOW TO RUN

1. Install dependency:

pip install requests

2. Run:

python main.py

---

## 📊 SAMPLE OUTPUT

Checking: https://www.google.com
Status: UP
Status Code: 200
Response Time: 1.44 seconds

Checking: https://invalid-example-domain-12345.com
Status: DOWN
Error: HTTPSConnectionPool(host='invalid-example-domain-12345.com', port=443): Max retries exceeded with url: / (Caused by NameResolutionError(...))

[ALERT] Email alert would be triggered here.
[ALERT] Slack notification would be triggered here.

---

## 🔔 ALERT BEHAVIOR

This system supports real Email and Slack alerts.

### 👉 Default (No Setup)

If alert configuration is not provided, the system will show:

[ALERT] Email alert would be triggered here
[ALERT] Slack notification would be triggered here

---

### 👉 Real Alert Mode (Optional)

To receive real alerts:

• Configure SMTP email credentials
• Add a valid Slack webhook URL

---

💡 You can run this system without any setup for testing.

---

## ⚠️ IMPORTANT

• Requires internet connection
• Test with sample URLs first
• Alerts work in simulation mode if not configured

---

## 💡 WANT MORE?

This is a simplified version of a real monitoring system.

The full Professional Pack includes:

✔ Advanced monitoring systems
✔ Alert integrations (Slack, Email, etc.)
✔ DevOps & QA automation workflows
✔ 35+ production-ready systems

👉 DM to get full access
