import os
import time
import sys
import shutil
from config import LOG_DIR, BACKUP_DIR, DAYS_TO_KEEP

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_DIR = os.path.join(BASE_DIR, LOG_DIR)
BACKUP_DIR = os.path.join(BASE_DIR, BACKUP_DIR)

seconds_in_day = 24 * 60 * 60

def clear_screen():
    os.system("clear")  # Linux terminal clear

def scan_and_cleanup():
    now = time.time()
    moved_files = 0
    checked_files = 0
    activity_logs = []

    if not os.path.exists(LOG_DIR):
        activity_logs.append("[ERROR] Log directory not found.")
        return checked_files, moved_files, activity_logs

    os.makedirs(BACKUP_DIR, exist_ok=True)
    backup_folder_name = os.path.basename(BACKUP_DIR)

    for filename in os.listdir(LOG_DIR):
        file_path = os.path.join(LOG_DIR, filename)

        if os.path.isfile(file_path) and filename.lower().endswith(".log"):
            checked_files += 1
            last_modified = os.path.getmtime(file_path)
            age_in_days = (now - last_modified) / seconds_in_day

            if age_in_days > DAYS_TO_KEEP:
                try:
                    backup_path = os.path.join(BACKUP_DIR, filename)
                    shutil.move(file_path, backup_path)
                    moved_files += 1

                    timestamp = time.strftime('%H:%M:%S')
                    activity_logs.append(
                        f"[{timestamp}] MOVED: {filename} → {backup_folder_name}/"
                    )

                except Exception as e:
                    activity_logs.append(f"[ERROR] {filename}: {e}")

    return checked_files, moved_files, activity_logs


# ================= REAL-TIME MONITOR LOOP =================

while True:
    checked, moved, logs = scan_and_cleanup()

    clear_screen()

    print("======================================")
    print("   REAL-TIME LOG CLEANUP MONITOR")
    print("======================================\n")

    print(f"Log Folder        : {LOG_DIR}")
    print(f"Backup Folder     : {BACKUP_DIR}")
    print(f"Retention Policy  : {DAYS_TO_KEEP} days")
    print(f"Last Scan Time    : {time.strftime('%Y-%m-%d %H:%M:%S')}\n")

    print("------------ SCAN SUMMARY ------------")
    print(f"Files Checked     : {checked}")
    print(f"Files Moved       : {moved}\n")

    print("------------ LIVE ACTIVITY -----------")
    if logs:
        for entry in logs[-5:]:  # show last 5 events
            print(entry)
    else:
        print("No old log files found.")

    print("\nNext scan in 60 seconds...")
    time.sleep(60)