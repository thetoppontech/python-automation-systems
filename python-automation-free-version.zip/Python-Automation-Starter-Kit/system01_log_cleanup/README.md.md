# 🚀 Log Cleanup Automation System

---

## 📌 WHAT THIS DOES

Automatically moves old `.log` files to a backup folder based on a retention period.

Helps keep your system clean and prevents disk space issues.

---

## ⚡ HOW IT WORKS

* Scans the log folder
* Checks file age
* Moves old logs to backup folder
* Displays activity in terminal

---

## ⚙️ CONFIGURATION

Open `config.py` and update:

* `LOG_DIR` → Folder containing log files
* `BACKUP_DIR` → Folder where old logs are stored
* `DAYS_TO_KEEP` → Number of days before cleanup

Example:

LOG_DIR = "logs"
BACKUP_DIR = "logs_backup"
DAYS_TO_KEEP = 7

---

## ▶️ HOW TO RUN

1. Open terminal
2. Navigate to this folder
3. Run:

python main.py

---

## 📊 SAMPLE OUTPUT

[MOVED] app_old.log → logs_backup/
[MOVED] error_old.log → logs_backup/

Files Checked: 5
Files Moved: 2

Log cleanup completed successfully.

---

## ⚠️ IMPORTANT

* Test on sample files first
* Verify folder paths
* Avoid using important system directories

---

## 💡 WANT MORE?

This is a simplified version of a complete automation system.

The full Professional Pack includes:

✔ 35+ automation systems
✔ Monitoring + alerts
✔ DevOps & QA workflows
✔ Production-ready implementations

👉 DM to get full access
