# ============================================================
# Script 01: Automated Log Cleanup System
# Configuration File
# ============================================================

# Log folder to clean (relative to script directory)
LOG_DIR = "logs"

# Backup folder for deleted logs
BACKUP_DIR = "logs_backup"

# Retention period in days
DAYS_TO_KEEP = 7