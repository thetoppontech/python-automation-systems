# 🚀 Automated Backup System

---

## 📌 WHAT THIS DOES

Creates a complete backup of your files with a timestamp.

Helps protect your data from accidental loss or system failures.

---

## ⚡ HOW IT WORKS

* Reads source folder from config
* Creates a timestamped backup folder
* Copies all files and subfolders
* Shows success message in terminal

---

## ⚙️ CONFIGURATION

Open `config.py` and update:

* `SOURCE_DIR` → Folder you want to back up
* `BACKUP_ROOT` → Folder where backups will be stored

Example:

SOURCE_DIR = "project_data"
BACKUP_ROOT = "backups"

---

## ▶️ HOW TO RUN

1. Place your files inside the source folder
2. Open terminal
3. Run:

python main.py

---

## 📊 SAMPLE OUTPUT

[SUCCESS] Backup created at: backups/backup_2026-03-23_18-30-10

Backup process completed successfully.

---

## ⚠️ IMPORTANT

* Make sure the source folder exists
* Ensure enough disk space for backup
* Backups are copied (original files remain unchanged)

---

## 💡 WANT MORE?

This is a simplified version of a real automation system.

The full Professional Pack includes:

✔ 35+ automation systems
✔ Monitoring + alert systems
✔ DevOps & QA workflows
✔ Production-ready implementations

👉 DM to get full access
