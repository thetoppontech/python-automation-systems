# ============================================================
# Script 3 — Automated Backup Creation
# Configuration File
# ============================================================

# Folder to be backed up (relative to script directory)
SOURCE_DIR = "project_data"

# Root folder where backups will be stored
BACKUP_ROOT = "backups"
