import os
import shutil
from datetime import datetime
from config import SOURCE_DIR, BACKUP_ROOT

# -------------------------------------------------
# Ensure script runs from its own directory
# -------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE_DIR)

print("\nStarting Automated Backup Process\n")
print(f"Source Folder: {SOURCE_DIR}")
print(f"Backup Root: {BACKUP_ROOT}\n")

# -------------------------------------------------
# Validate source directory
# -------------------------------------------------
if not os.path.exists(SOURCE_DIR):
    print("[ERROR] Source directory not found:", SOURCE_DIR)
    exit(1)

# -------------------------------------------------
# Ensure backup root exists
# -------------------------------------------------
os.makedirs(BACKUP_ROOT, exist_ok=True)

# -------------------------------------------------
# Create timestamped backup folder
# -------------------------------------------------
timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
backup_folder_name = f"backup_{timestamp}"
backup_path = os.path.join(BACKUP_ROOT, backup_folder_name)

# -------------------------------------------------
# Perform backup
# -------------------------------------------------
try:
    shutil.copytree(SOURCE_DIR, backup_path)
    print("[SUCCESS] Backup created at:", backup_path)
except Exception as e:
    print("[ERROR] Backup failed:", str(e))
    exit(1)

print("\nBackup process completed successfully.")
exit(0)
