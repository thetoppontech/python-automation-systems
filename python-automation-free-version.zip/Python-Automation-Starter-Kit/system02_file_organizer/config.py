# ============================================================
# Script 2 — File Organization by Extension
# Configuration File
# ============================================================

# Folder containing mixed files (relative to script directory)
SOURCE_DIR = "downloads"

# Default folder for unknown file types
DEFAULT_FOLDER = "others"

# Extension-to-folder mapping
EXTENSION_MAP = {
    "jpg": "images",
    "jpeg": "images",
    "png": "images",

    "log": "logs",
    "txt": "logs",

    "csv": "data",
    "xlsx": "data"
}

# Safety options
OVERWRITE_EXISTING = False   # If False, prevents overwriting files