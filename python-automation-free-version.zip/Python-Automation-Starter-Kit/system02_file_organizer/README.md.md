# 🚀 File Organizer Automation System

---

## 📌 WHAT THIS DOES

Automatically organizes messy folders by sorting files into categories like images, logs, and data.

Turn a cluttered folder into a clean structure in seconds.

---

## ⚡ HOW IT WORKS

* Scans all files in the source folder
* Detects file type (extension)
* Moves files into matching folders
* Creates folders automatically if needed

---

## ⚙️ CONFIGURATION

Open `config.py` and update:

* `SOURCE_DIR` → Folder containing mixed files
* `EXTENSION_MAP` → File types and their destination folders
* `DEFAULT_FOLDER` → Folder for unknown file types

Example:

SOURCE_DIR = "downloads"

EXTENSION_MAP = {
"jpg": "images",
"png": "images",
"txt": "logs",
"csv": "data"
}

DEFAULT_FOLDER = "others"

---

## ▶️ HOW TO RUN

1. Place files inside the source folder
2. Open terminal
3. Run:

python main.py

---

## 📊 SAMPLE OUTPUT

[MOVED] photo1.jpg → images/
[MOVED] report.csv → data/
[MOVED] notes.txt → logs/
[MOVED] random.bin → others/

---

Files Moved   : 8
Files Skipped : 0
-----------------

File organization completed successfully.

---

## ⚠️ IMPORTANT

* Test on sample folders first
* Avoid organizing important system folders
* Files are moved (not copied)

---

## 💡 WANT MORE?

This is a simplified version of a real automation system.

The full Professional Pack includes:

✔ 35+ automation systems
✔ Monitoring + alert systems
✔ DevOps & QA workflows
✔ Production-ready implementations

👉 DM to get full access
