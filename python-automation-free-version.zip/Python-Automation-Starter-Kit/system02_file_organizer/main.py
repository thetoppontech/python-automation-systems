import os
import shutil
from config import SOURCE_DIR, EXTENSION_MAP, DEFAULT_FOLDER, OVERWRITE_EXISTING

print("\nStarting Advanced File Organization\n")
print(f"Source Folder: {SOURCE_DIR}\n")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SOURCE_PATH = os.path.join(BASE_DIR, SOURCE_DIR)

if not os.path.exists(SOURCE_PATH):
    print("[ERROR] Source directory not found:", SOURCE_PATH)
    exit(1)

moved_files = 0
skipped_files = 0

for filename in os.listdir(SOURCE_PATH):
    file_path = os.path.join(SOURCE_PATH, filename)

    # Ignore folders
    if not os.path.isfile(file_path):
        continue

    name, ext = os.path.splitext(filename)
    ext = ext[1:].lower()

    target_folder = EXTENSION_MAP.get(ext, DEFAULT_FOLDER)
    target_dir = os.path.join(SOURCE_PATH, target_folder)
    os.makedirs(target_dir, exist_ok=True)

    destination = os.path.join(target_dir, filename)

    # Collision handling
    if os.path.exists(destination) and not OVERWRITE_EXISTING:
        print(f"[SKIPPED] {filename} (already exists)")
        skipped_files += 1
        continue

    shutil.move(file_path, destination)
    print(f"[MOVED] {filename} -> {target_folder}/")
    moved_files += 1

print("\n------------------------------")
print(f"Files Moved   : {moved_files}")
print(f"Files Skipped : {skipped_files}")
print("------------------------------")

print("\nFile organization completed successfully.")
