# 🚀 Email Alert System for Failures

---

## 📌 WHAT THIS DOES

Automatically detects failures in an automation task and triggers an alert.

Helps you identify issues instantly instead of manually checking logs.

---

## ⚡ HOW IT WORKS

• Runs an automation task
• Detects failure (error)
• Triggers alert system
• Displays alert status in terminal

---

## ⚙️ CONFIGURATION

Open `config.py` and update:

• `SENDER_EMAIL` → Your email (required for real alerts)
• `ALERT_RECIPIENTS` → List of emails to notify

---

## ▶️ HOW TO RUN

Run:

python main.py

---

## 📊 SAMPLE OUTPUT

==================================================
EMAIL ALERT MONITORING SYSTEM
=============================

Status           : RUNNING
Start Time       : 2026-03-24 11:22:29

------------ FAILURE DETECTED ------------
Error Type       : FileNotFoundError
Error Message    : Input file not found: daily_backup.zip

------------ ALERT TRIGGERED ------------
[ALERT] Email alert would be triggered here. (simulation mode)

------------ SYSTEM STATUS --------------
Alert Status     : SIMULATED
Alert Time       : 11:22:33
System State     : FAILURE HANDLED

==================================================

---

## 🔔 ALERT BEHAVIOR

This system supports real email alerts.

For easy testing, it runs in **simulation mode by default**.

This means:

• No setup is required
• Alert behavior is shown in terminal
• System works instantly

👉 To enable real alerts:

• Configure email credentials (SMTP)
• Set environment variables (`EMAIL_USER`, `EMAIL_PASS`)

---

## ⚠️ IMPORTANT

• Use an App Password (not your email password)
• Restart terminal after setting environment variables
• Ensure internet connection is active

---

## 💡 WANT MORE?

This is a simplified version of a real alerting system.

The full Professional Pack includes:

✔ Advanced alert systems
✔ Multi-channel alerts (Email, Slack, etc.)
✔ Failure handling workflows
✔ DevOps & QA automation systems
✔ 35+ production-ready systems

👉 DM to get full access

---

## 🚀 WHY THIS SYSTEM MATTERS

Automation is not just about running scripts.

It’s about detecting failures and reacting instantly.

This system introduces you to real-world alerting concepts used in production environments.
