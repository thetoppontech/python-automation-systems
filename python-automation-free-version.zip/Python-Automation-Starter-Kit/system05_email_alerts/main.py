import os
import sys
import smtplib
import socket
from email.mime.text import MIMEText
from datetime import datetime

from config import (
    SMTP_SERVER,
    SMTP_PORT,
    EMAIL_SUBJECT,
    SENDER_EMAIL,
    ALERT_RECIPIENTS,
    PRINT_TO_TERMINAL
)


# ------------------------------------------------------------
# EMAIL ALERT FUNCTION (WITH SAFE FALLBACK)
# ------------------------------------------------------------

def send_failure_alert(error_message):

    failure_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    hostname = socket.gethostname()

    message_body = f"""
Automation Script Failure Detected

Time: {failure_time}
Host: {hostname}

Error Details:
{error_message}
"""

    email_user = os.getenv("EMAIL_USER")
    email_pass = os.getenv("EMAIL_PASS")

    # ✅ SIMULATION MODE (NO SETUP)
    if not email_user or not email_pass:
        print("[ALERT] Email alert would be triggered here. (credentials not set)")
        return False

    # ✅ REAL EMAIL MODE
    try:
        msg = MIMEText(message_body)
        msg["Subject"] = EMAIL_SUBJECT
        msg["From"] = SENDER_EMAIL
        msg["To"] = ", ".join(ALERT_RECIPIENTS)

        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(email_user, email_pass)
            server.sendmail(SENDER_EMAIL, ALERT_RECIPIENTS, msg.as_string())

        print("Email alert sent successfully.")
        return True

    except Exception as email_error:
        print(f"[ERROR] Email alert failed: {email_error}")
        return False


# ------------------------------------------------------------
# MAIN EXECUTION (PROFESSIONAL OUTPUT)
# ------------------------------------------------------------

def main():

    print("=" * 45)
    print("   EMAIL ALERT MONITORING SYSTEM")
    print("=" * 45)

    print("\nStatus           : RUNNING")
    print(f"Start Time       : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    try:
        # ---- SIMULATED FAILURE (FOR DEMO) ----
        raise FileNotFoundError("Input file not found: daily_backup.zip")

    except Exception as error:

        print("\n------------ FAILURE DETECTED ------------")
        print(f"Error Type       : {type(error).__name__}")
        print(f"Error Message    : {error}")

        print("\n------------ ALERT TRIGGERED ------------")

        success = send_failure_alert(str(error))

        print("\n------------ SYSTEM STATUS --------------")

        if success:
            print("Alert Status     : SENT (REAL)")
        else:
            print("Alert Status     : SIMULATED")

        print(f"Alert Time       : {datetime.now().strftime('%H:%M:%S')}")
        print("System State     : FAILURE HANDLED")

        print("\n=========================================")
        sys.exit(1)

    print("\nTask completed successfully.")
    sys.exit(0)


# ------------------------------------------------------------
# ENTRY POINT
# ------------------------------------------------------------

if __name__ == "__main__":
    main()