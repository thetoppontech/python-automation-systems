# ============================================
# System 04 — Email Alerts for Failures
# Configuration File
# ============================================

# SMTP server settings
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587

# Email subject for alerts
EMAIL_SUBJECT = "ALERT: Automation Script Failure Detected"

# Sender email address
SENDER_EMAIL = "your_email@gmail.com"   # Replace to enable real alerts

# Alert recipients
ALERT_RECIPIENTS = [
    "your_email@gmail.com"
]

# Enable console output
PRINT_TO_TERMINAL = False